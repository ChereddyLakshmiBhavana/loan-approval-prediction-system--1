from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="loan-approval-prediction",
    version="1.0.0",
    author="Loan Prediction Team",
    description="AI-Driven Loan Approval Prediction System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.23.0",
        "pandas>=1.5.0",
        "scikit-learn>=1.3.0",
        "tensorflow>=2.13.0",
        "keras>=2.13.0",
        "flask>=2.3.0",
        "flask-cors>=4.0.0",
    ],
    entry_points={
        "console_scripts": [
            "loan-prediction-api=src.api.app:run_app",
        ],
    },
)
