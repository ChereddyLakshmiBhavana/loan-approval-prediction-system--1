"""Data processing module"""
